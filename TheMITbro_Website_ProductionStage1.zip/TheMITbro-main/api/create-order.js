import Razorpay from "razorpay";
import { getProduct } from "./_lib/catalog.js";
const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
export default async function handler(req,res){
 if(req.method!=="POST") return res.status(405).json({success:false,message:"Method Not Allowed"});
 try{
  const {paperId}=req.body||{}; const product=getProduct(paperId);
  if(!product || product.status!=="available" || !product.privateFile || product.priceRupees<=0) return res.status(400).json({success:false,message:"Paper is not available for purchase."});
  const order=await razorpay.orders.create({amount:product.priceRupees*100,currency:"INR",receipt:`receipt_${paperId}_${Date.now()}`,notes:{paperId}});
  return res.status(200).json({success:true,key:process.env.RAZORPAY_KEY_ID,orderId:order.id,amount:order.amount,currency:order.currency,paperId,title:product.title});
 }catch(err){ console.error("create-order",err); return res.status(500).json({success:false,message:"Unable to create order"}); }
}
